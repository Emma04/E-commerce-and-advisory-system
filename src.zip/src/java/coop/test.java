/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coop;

import coop.db.MyCo;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Satellite
 */
public class test extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ParseException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            MyCo db = new MyCo();
            Connection co = db.getCo();
                     if (co == null) {
                             out.print("connection failed");
                                      }
                     else {
                             out.println("<html lang=\"en\">\n" +
"<head>\n" +
"  <title>Moussahama</title>\n" +
"  <meta charset=\"utf-8\">\n" +
"  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"  <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">\n" +
"  <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>\n" +
"  <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>\n" +
"  <style>\n" +
"    /* Remove the navbar's default margin-bottom and rounded borders */ \n" +
"    .navbar {\n" +
"      margin-bottom: 0;\n" +
"      border-radius: 0;\n" +
"    }\n" +
"    \n" +
"    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */\n" +
"    .row.content {height: 450px}\n" +
"    \n" +
"    /* Set gray background color and 100% height */\n" +
"    .sidenav {\n" +
"      padding-top: 20px;\n" +
"      background-color: #f1f1f1;\n" +
"      height: 100%;\n" +
"    }\n" +
"    \n" +
"    /* Set black background color, white text and some padding */\n" +
"    footer {\n" +
"      background-color: #555;\n" +
"      color: white;\n" +
"      padding: 15px;\n" +
"    }\n" +
"    \n" +
"    /* On small screens, set height to 'auto' for sidenav and grid */\n" +
"    @media screen and (max-width: 767px) {\n" +
"      .sidenav {\n" +
"        height: auto;\n" +
"        padding: 15px;\n" +
"      }\n" +
"      .row.content {height:auto;} \n" +
"    }\n" +
"  </style>\n" +
"</head>\n" +
"<body>\n" 
                        );
                 out.println("<style type=\"text/css\">\n" +
"            .fancy{\n" +
"                font-family: cursive;\n" +
"                    color: #2B3856;\n" +
"            }\n" +
"            .product{\n" +
"                font-family: cursive;\n" +
"                    color: #C85A17;\n" +
"            }\n" +
"             .ad{\n" +
"                    color: #7F462C;\n" +
"            }\n" +
"            \n" +
"        </style>");
                out.println(
"<nav class=\"navbar navbar-inverse\">\n" +
"  <div class=\"container-fluid\">\n" +
"    <div class=\"navbar-header\">\n" +
"      <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#myNavbar\">\n" +
"        <span class=\"icon-bar\"></span>\n" +
"        <span class=\"icon-bar\"></span>\n" +
"        <span class=\"icon-bar\"></span>                        \n" +
"      </button>\n" +
"      <a class=\"navbar-brand\" href=\"#\">Moussahama     &nbsp;</a>\n" +
"    </div>\n" +
"    <div class=\"collapse navbar-collapse\" id=\"myNavbar\">\n" +
"      <ul class=\"nav navbar-nav\">\n" +
"              <li><a href=\"#\"></a></li>\n" +
"           <li><a href=\"#\"></a></li>\n" +
"        <li class=\"active\"><a href=\"test\">Home</a></li>\n" +
"           <li><a href=\"#\"></a></li>\n" +
"           <li><a href=\"#\"></a></li>\n" +
"        <li><a href=\"gamyown.html\">Analytics</a></li>\n" +
"        <li><a href=\"setting.html\">Settings</a></li>\n" +
"     \n" +
"      </ul>\n" +
"    </div>\n" +
"  </div>\n" +
"</nav>\n");
                out.println("<div align=\"center\" id=\"image-holder\">\n" +
"            <img src=\"coop.jpg\" width=\"480\" height=\"670\" align=\"right\" />\n" +
"        </div>");
                    Statement st = co.createStatement();
                    Calendar cal = Calendar.getInstance();
                // out.println("we are  "+today);
                    String dateEvent = "select * from event;";
                    ResultSet rs = st.executeQuery(dateEvent);
              
                   out.println("<div align=\"center\" >");
                        out.print("</br>");  out.print("</br>");  out.print("</br>");  out.print("</br>");
                    Date tod = new Date();  //today date
              
                    int monthToday = cal.get(Calendar.MONDAY)+1;
                    int dayToday= cal.get(Calendar.DAY_OF_MONTH); //useful for condition based on month and day
                
                    int day =  31; //enter month * 30 to have days
               
                             while (rs.next()) {
                    String idE= rs.getString("idEVENT");
                    int idEvent = Integer.parseInt(idE);
                    Date dateE = rs.getDate("DATE_EVENT");
                    String name = rs.getString("NAME_EVENT");
                    long diffInMillies = Math.abs(dateE.getTime() - tod.getTime());  //still absolute but will verify condition in if later
                    long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
                    int monthEvent = dateE.getMonth() + 1; //+1 coz it start from 0
                    int dayEvent=dateE.getDate(); //useful for condition based on month and day
                    
                    String po="select count(order_product.PRODUCT_NAME), order_product.PRODUCT_NAME from order_product, product, orders, event, match_pro_and_event where order_product.PRODUCT_SKU= product.SKU and match_pro_and_event.idEVENT="+ idEvent+"  and match_pro_and_event.PRODUCT_ID=product.PRODUCT_ID and event.NAME_EVENT='"+ name+"' and order_product.ORDER_ID=orders.ORDER_ID and (month(orders.DATE_PURCHASED) between "+ monthToday+" and " + monthEvent + ") and (day(orders.DATE_PURCHASED) between "+ dayToday+" and " + dayEvent + ")group by order_product.PRODUCT_NAME order by count(order_product.PRODUCT_NAME) desc limit 3;";                   
                    String less= " select count(order_product.PRODUCT_NAME), order_product.PRODUCT_NAME from order_product, orders where order_product.ORDER_ID = orders.ORDER_ID and (month(orders.DATE_PURCHASED) between "+ monthToday+" and " + monthEvent + ") and (day(orders.DATE_PURCHASED) between "+ dayToday + " and " + dayEvent + ")group by order_product.PRODUCT_NAME order by count(order_product.PRODUCT_NAME) asc limit 1;";
                    ResultSet re = co.createStatement().executeQuery(po);
                    ResultSet le = co.createStatement().executeQuery(less);
                    
                    
                    //    we are listing event btw today and events within  month
                            if (diff <= day) {
                      
                        //if we are 01 feb we still can see event coming like valentine 
                                if(monthToday==monthEvent ){ //verify condition ony event coming are apearing bc in the previous condition its based on absolute value
                                    if(dayToday<dayEvent){ //for same month today should be less 
                        // String pro="select order_product.PRODUCT_NAME from order_product, orders where ( orders.DATE_PURCHASED between "+s+" and "+dateE+";" ; //should be btw months
                                            out.println("<table>\n");
                                            out.print("<tr>\n");
                                            out.print("</br>");
                                        if(re.next()){
                                            out.println("<td>" +"For "+name );
                                            out.println(", clients have <b>favorited </b> those articles : ");
                                              //    out.print("</br>");
                                        
                                                   while (re.next())  {
                                                           out.println("<i class=\"product\">");
                                                           out.println(re.getString("order_product.PRODUCT_NAME" )+ ", " );
                                                           out.println("</i>");
                                                                       }
                                                           out.println(" </td>\n");
                                                           out.print("</tr>\n");
                                                             //out.print("</br>");
                                                         }
                                                           out.print("<tr>\n");
                                                           out.print("</br>");
                                                           out.println(" <td>\n");
                                                           //out.println(" But ");     
                                                 while (le.next()) {
                                                out.println("<i class=\"product\">");
                                                out.println( le.getString("order_product.PRODUCT_NAME") + " " );
                                                out.println("</i>");
                                                                   }  
                          
                                                out.println("hasn't been popular for "+name + ".</b> ");
                                                out.println(" </td>\n");
                                                out.print("</tr>\n");
                        
                                                        //   out.print("</br>");
                                                out.println("</table>\n");
                                                              }
                                                     }
                                            if (monthToday<monthEvent ){ //verify condition ony event coming are apearing bc in the previous condition its based on absolute value
                      
                            //we separate date for sql syntaxe  (between smaller and bigger) otherwise empty result
                         
                                                 if(dayToday<dayEvent){ 
                                                     if(re.next()){
                                                       out.println("<table>\n");
                                                       out.print("<tr>\n");
                                                       out.print("</br>");
                                                       out.println("<td>" +name + " is approaching, ");
                                                       out.print("the products ");
                                                     while (re.next()) {
                                                            out.println("<i class=\"product\">");
                                                            out.println( re.getString("order_product.PRODUCT_NAME") + ", " );
                                                            out.println("</i>");
                                                                      }
                                                                    }
                                                            out.print("</br>");
                                                            out.println("<b class=\"ad\">Make sure you don't run out of stock !</b>");
                       // out.print("</br>");
                                                            out.print("</tr>\n");
                                                            out.print("<tr>\n");
                                                            out.print("<td> And in the opposite, the product ");
                                                     while (le.next()) {
                                                            out.println("<i class=\"product\">");
                                                            out.println( le.getString("order_product.PRODUCT_NAME") + " " );
                                                            out.println("</i>");
                                                                        }  
                                                            out.print("hasn't been sold. </td>");
                                                            out.print("</tr>\n");
                                                            out.println("</table>\n");
                        //out.print("</br>");
                                                                        }
                       
                                                  if(dayToday>dayEvent){ 
                                                      if(re.next()){
                                                          
                                                            
                                                            out.println("<table>\n");
                                                            out.print("<tr>\n");
                                                            out.print("</br>");
                                                            out.println("<td>" +"For : "+name + "</td>\n");
                                                            out.print("</tr>\n");
                                                            out.print("<tr>\n");
                                                            out.println("<td>" );
                                                                  while (re.next()) {
                                                            out.println("<i class=\"product\">");
                                                            out.println( re.getString("order_product.PRODUCT_NAME"));
                                                            out.println("</i>");
                                                                      }
                                                                   
                                                            out.print("</br>");
                                                            out.println(" was among <b>the best selling product.  </b>   </td>\n");
                                                            out.print("</tr>\n");
                                                            out.print("</br>");
                                                            out.print("</br>");
                                                                    }
                                                            out.println("</br>");       out.println("</br>");       out.println("</br>");       out.println("</br>");
                                                            out.print("</br>");
                                                            out.print("<tr>\n");
                                                         
                                                        while (le.next()) {
                                                            out.println("<td>"+"But " );
                                                            out.println("<i class=\"product\">");
                                                            out.println( le.getString("order_product.PRODUCT_NAME"));
                                                            out.println("</i>");
                                                            out.println("hasn't known a similar success</td>" );
                                                                          }
                                                           
                                                            out.print("</tr>\n");
                                                            out.print("</br>");
                                                            out.println("</table>\n");
                                                                            } 
                                                                                    }
                      
                                }
          
            } //end rs.next
                              out.println("</div>");
                  out.println(
"</body>\n" +
"</html>\n" +
"");
        }
    }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
